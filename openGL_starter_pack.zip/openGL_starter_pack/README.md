Hi there! :D

I'm UNK Alumni Carson Mead.
    If you're reading this, you either got this "package" from Adam in class, 
AND/ OR required a simple start to an OpenGL project in c using GLFW and GLEW on Linux(debian).

    First, OpenGL is an open source graphical language, hence the name.  It is extremely low-level, and is
vector-based.  So, it's important to have some handle on mathematics.  Anyway, OpenGL is specifically designed
to utilize the GPU.  It is cross-language, so you can implement it using many other programming languages, but
here we will be implementing in c for speed and some challenge >:)

    Next, GLFW and GLEW are packages for making the OpenGL process go a bit smoother.  GLFW is a context
and window managment dev-kit for OpenGL.  Basically, it opens a blank window.  then, OpenGL requires you to 
import every function you plan to use.  GLEW instead, imports those functions for us.  This is in theory makes
the OpenGL project process marginally simpler.

    Again, this is only the starter to an OpenGL project.  This will not have examples of the OpenGL functions
or their uses.
